﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using EmployeeMvc.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace EmployeeMvc.Controllers
{
    public class DbContextHealthCheck : IHealthCheck
    {

        private readonly EmployeeContext _dbContext;

        public DbContextHealthCheck(EmployeeContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            return await _dbContext.Database.CanConnectAsync(cancellationToken)
                 ? HealthCheckResult.Healthy()
              : HealthCheckResult.Unhealthy();
        }

    }
}