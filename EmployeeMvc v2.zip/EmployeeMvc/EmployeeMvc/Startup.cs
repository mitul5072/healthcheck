﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.AspNetCore.Internal;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using EmployeeMvc.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using EmployeeMvc.Controllers;
using Newtonsoft.Json.Linq;

namespace EmployeeMvc
{
    public class Startup
    {

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddDefaultIdentity<IdentityUser>().AddEntityFrameworkStores<EmployeeContext>();
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
            var connectionString = this.Configuration.GetConnectionString("DevConnection");

            services.AddRouting();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddDbContext<EmployeeContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("DevConnection")));

            //services.AddHealthChecks().AddSqlServer(Configuration.GetConnectionString("DevConnection"));

            services.AddHealthChecks().AddCheck<DbContextHealthCheck>("Employee Database HealthCheck")

            .AddCheck("APIvPing Check", () =>
            {
                try
                {
                    using (var ping = new Ping())
                    {
                        var reply = ping.Send("localhost");
                        if (reply.Status != IPStatus.Success)
                        {
                            return HealthCheckResult.Unhealthy();
                        }
                        if (reply.RoundtripTime > 100)
                        {
                            return HealthCheckResult.Degraded();
                        }
                        return HealthCheckResult.Healthy();
                    }

                }
                catch
                {
                    return HealthCheckResult.Unhealthy();
                }
            })
            .AddDbContextCheck<EmployeeContext>("DbContextCheck");


            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "AcccountsAPI", Version = "v1" });
            });
            services.AddHealthChecksUI();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }
            app.UseHealthChecksUI(setup => { setup.ApiPath = "/hc"; setup.UIPath = "/healthcheckui"; });
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();
            app.UseMvcWithDefaultRoute();


            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Accounts API V1");
            });



            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");

            });


            app.UseHealthChecks("/employee/health", new HealthCheckOptions
            {
                ResultStatusCodes =
                 {
                            [HealthStatus.Healthy] = StatusCodes.Status200OK,
                            [HealthStatus.Degraded] = StatusCodes.Status200OK,
                            [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable,


                 },
                ResponseWriter = WriteHealthCheckResponse




            }
         );

        }

        private Task WriteHealthCheckResponse(HttpContext httpcontext, HealthReport result)
        {
            httpcontext.Response.ContentType = "application/json";
            var json = new JObject
            (
                                new JProperty("OverallStatus", result.Status.ToString()),
                                new JProperty("TotalCheckDuration", result.TotalDuration.TotalSeconds.ToString("0:00:00:00")),
                                new JProperty("DependencyHealthCheck", new JObject(result.Entries.Select(dicItem =>
                                new JProperty(dicItem.Key, new JObject(
                                             new JProperty("STATUS", dicItem.Value.Status.ToString()),
                                             new JProperty("DURAATION", dicItem.Value.Duration.TotalSeconds.ToString("0:00:00:00"))


                                             )
                                ))))




                 );

            return httpcontext.Response.WriteAsync(json.ToString(Newtonsoft.Json.Formatting.Indented));
        }

    }

}

                

                
                
           
      
    
